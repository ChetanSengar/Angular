export const RECAPTCHA_KEY = '6Lcd3jcaAAAAAJBzuA87E96l9hcq3inCgJCQbRn5';
