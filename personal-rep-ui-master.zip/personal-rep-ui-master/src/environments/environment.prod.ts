export const environment = {
  production: true,
  presentationApi: 'https://tc-ipp-api.herokuapp.com/api/v1',
  authToken: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxM' +
    'jM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.' +
    'drt_po6bHhDOF_FJEHTrK-KD8OGjseJZpHwHIgsnoTM',
  IAOrSDPhoneNumber: '<IA or SD phone number>',
};
