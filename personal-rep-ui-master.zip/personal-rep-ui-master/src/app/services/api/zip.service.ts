import { Injectable } from '@angular/core';
import { ApiBaseService } from './api-base.service';
import { Observable } from 'rxjs';
import { ZipCodeResponse } from '../../models/zip-code-response';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ZipService extends ApiBaseService {

  constructor(private http: HttpClient) {
    super('zip-code');
  }

  getZipCodeInfo(zipCode: string): Observable<ZipCodeResponse> {
    return this.http.get<ZipCodeResponse>(this.endpoint(zipCode), { headers: this.authHeaders });
  }
}
