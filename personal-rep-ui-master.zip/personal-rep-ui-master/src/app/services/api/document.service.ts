import { Injectable } from '@angular/core';
import { ApiBaseService } from './api-base.service';
import { CreateDocumentLinkRequest } from '../../models/create-document-link-request';
import { CreateDocumentLinkResponse } from '../../models/create-document-link-response';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DocumentService extends ApiBaseService {

  constructor(private http: HttpClient) {
    super('document-link');
  }

  createDocumentLink(documentRequest: CreateDocumentLinkRequest): Observable<CreateDocumentLinkResponse> {
    return this.http.post<CreateDocumentLinkResponse>(
      this.endpoint(),
      documentRequest,
      { headers: this.authHeaders }
    );
  }
}
