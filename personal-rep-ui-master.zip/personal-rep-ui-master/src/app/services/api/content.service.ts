import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiBaseService } from './api-base.service';
import { Observable } from 'rxjs';
import { ContentResponse } from '../../models/content-response';

@Injectable({
  providedIn: 'root'
})
export class ContentService extends ApiBaseService{

  constructor(private http: HttpClient) {
    super('content');
  }

  getContent(): Observable<ContentResponse> {
    return this.http.get<ContentResponse>(this.endpoint(), { headers: this.authHeaders });
  }
}
