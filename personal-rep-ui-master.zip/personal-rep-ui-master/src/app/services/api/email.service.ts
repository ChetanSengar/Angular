import { Injectable } from '@angular/core';
import { ApiBaseService } from './api-base.service';
import { SendEmailRequest } from '../../models/send-email-request';
import { Observable } from 'rxjs';
import { SendEmailResponse } from '../../models/send-email-response';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmailService extends ApiBaseService {

  constructor(private http: HttpClient) {
    super('createEmail');
  }

  createEmail(createEmailRequest: SendEmailRequest): Observable<SendEmailResponse> {
    return this.http.post<SendEmailResponse>(
      this.endpoint(),
      createEmailRequest,
      {headers: this.authHeaders}
    );
  }
}
