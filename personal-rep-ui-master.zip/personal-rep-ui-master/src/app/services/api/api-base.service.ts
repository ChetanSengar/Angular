import { isDefined } from '../../utils/validation.util';
import { environment } from '../../../environments/environment';
import { HttpHeaders } from '@angular/common/http';

const {
  presentationApi,
  authToken
} = environment;

export interface UnrefinedParams {
  [key: string]: any;
}

export class ApiBaseService {
  // endpoint base url
  protected readonly endpointBase: string;
  // api host
  protected readonly host: string = presentationApi;

  constructor(
    path = '',
  ) {
    this.endpointBase = this.host + '/' + path;
  }

  /**
   * get api endpoint
   * @param path path
   */
  endpoint(path = ''): string {
    return this.endpointBase + '/' + path;
  }

  /**
   * create http params from object type params
   * @param params params
   */
  getHttpParams(params: UnrefinedParams): { [k: string]: string } {
    const refined: { [k: string]: string } = {};

    Object.keys(params || {}).forEach(key => {
      if (isDefined(params[key])) {
        refined[key] = params[key] + '';
      }
    });

    return refined;
  }

  get authHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: authToken
    });
  }
}
