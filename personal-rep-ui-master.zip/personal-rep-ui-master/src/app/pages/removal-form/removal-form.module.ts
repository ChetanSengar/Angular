import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RemovalFormRoutingModule } from './removal-form-routing.module';
import { RemovalFormComponent } from './removal-form.component';
import { WellmarkBannerModule } from '@wellmark/wm-lib-ux';
import { StartModule } from '../../components/start/start.module';
import { StepperFormModule } from '../../components/stepper-form/stepper-form.module';


@NgModule({
  declarations: [RemovalFormComponent],
  imports: [
    CommonModule,
    RemovalFormRoutingModule,
    WellmarkBannerModule,
    StartModule,
    StepperFormModule
  ]
})
export class RemovalFormModule { }
