import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RemovalFormComponent } from './removal-form.component';

const routes: Routes = [
  {
    path: '',
    component: RemovalFormComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RemovalFormRoutingModule { }
