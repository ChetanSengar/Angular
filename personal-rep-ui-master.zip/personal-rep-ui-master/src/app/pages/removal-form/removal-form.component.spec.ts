import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RemovalFormComponent } from './removal-form.component';

describe('RemovalFormComponent', () => {
  let component: RemovalFormComponent;
  let fixture: ComponentFixture<RemovalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RemovalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemovalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
