import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingComponent } from './landing.component';
import { LandingRoutingModule } from './landing-routing.module';
import { WellmarkCardModule } from '@wellmark/wm-lib-ux';



@NgModule({
  declarations: [LandingComponent],
  imports: [
    CommonModule,
    LandingRoutingModule,
    WellmarkCardModule
  ]
})
export class LandingModule { }
