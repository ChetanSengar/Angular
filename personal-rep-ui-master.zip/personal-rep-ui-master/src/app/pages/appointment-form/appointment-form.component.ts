import { Component, OnInit } from '@angular/core';
import { ContentService } from '../../services/api/content.service';
import { BehaviorSubject } from 'rxjs';
import { ContentResponse } from '../../models/content-response';

@Component({
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html',
  styleUrls: ['./appointment-form.component.scss']
})
export class AppointmentFormComponent implements OnInit {

  show: 'start' | 'form' = 'start';

  content$: BehaviorSubject<ContentResponse> = new BehaviorSubject<ContentResponse>(null);

  constructor(private contentService: ContentService) { }

  ngOnInit(): void {
    this.contentService.getContent().subscribe(this.content$);
  }
}
