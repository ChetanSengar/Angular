import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppointmentFormRoutingModule } from './appointment-form-routing.module';
import { AppointmentFormComponent } from './appointment-form.component';
import { WellmarkBannerModule } from '@wellmark/wm-lib-ux';
import { StepperFormModule } from '../../components/stepper-form/stepper-form.module';
import { StartModule } from '../../components/start/start.module';
import { SuccessModule } from '../../components/success/success.module';


@NgModule({
  declarations: [AppointmentFormComponent],
  imports: [
    CommonModule,
    AppointmentFormRoutingModule,
    WellmarkBannerModule,
    StepperFormModule,
    StartModule,
    SuccessModule
  ]
})
export class AppointmentFormModule { }
