export const SIGNER_FORM_ERRORS = {
  hasPersonalRepresentative: {
    required: 'Please select Yes or No'
  },
  signerRelation: {
    required: 'Please select a relationship'
  },
  firstName: {
    required: 'Please enter the first name'
  },
  lastName: {
    required: 'Please enter the last name'
  },
  emailAddress: {
    required: 'Please enter an Email address',
    pattern: 'Please enter a valid Email address'
  },
  documentation: {
    required: 'Please upload documentation'
  },
  addressLine1: {
    required: 'Please enter the address'
  },
  addressLine2: {},
  zipCode: {
    required: 'Please enter a ZIP code',
    pattern: 'Please enter a valid ZIP code'
  },
  cityState: {
    required: 'Please select the city and state'
  }
};

export const SIGNER_FORM_NON_SELECTED_REP_ERRORS = {
  hasPersonalRepresentative: {
    required: 'Please select Yes or No'
  },
  signerRelation: {
    required: 'Please select a relationship'
  },
  firstName: {},
  lastName: {},
  emailAddress: {},
  documentation: {},
  addressLine1: {
    required: 'Please enter the address'
  },
  addressLine2: {},
  zipCode: {
    required: 'Please enter a ZIP code',
    pattern: 'Please enter a valid ZIP code'
  },
  cityState: {
    required: 'Please select the city and state'
  }
};

export const MEMBER_FORM_ERRORS = {
  firstName: {
    required: 'Please enter the first name',
  },
  lastName: {
    required: 'Please enter the last name',
  },
  dateOfBirth: {
    required: 'Please enter the date of birth',
    invalidDate: 'Please enter a valid Date'
  },
  withWellmarkId: {
    required: 'Please select an identification method'
  },
  wellmarkId: {},
  ssn: {
    required: 'Please enter the SSN',
    pattern: 'Please enter a valid Social Security Number (XXX-XX-XXXX)'
  },
  emailAddress: {
    required: 'Please enter an Email address',
    pattern: 'Please enter a valid Email address'
  },
  addressLine1: {
    required: 'Please enter the address',
  },
  addressLine2: {
  },
  zipCode: {
    required: 'Please enter a ZIP code',
    pattern: 'Please enter a valid ZIP code'
  },
  cityState: {
    required: 'Please select the city and state '
  },
};


export const MEMBER_FORM_WITH_WELLMARK_ID_ERRORS =
  Object.assign({}, MEMBER_FORM_ERRORS, {
    wellmarkId: {
      required: 'Please enter the Wellmark Id',
      pattern: 'Please enter a valid Wellmark Id'
    },
    last4ssn: {
      required: 'Please enter the last 4 number of the SSN',
      pattern: 'Please enter a valid last 4 numbers of the SSN'
    },
  });

export const PERSONAL_PREP_FORM_ERRORS = {
  isAppointingPersonalRepresentative: {
    required: 'Please select Yes or No',
  },
  firstName: {
    required: 'Please enter the first name',
  },
  lastName: {
    required: 'Please enter the last name',
  },
  dateOfBirth: {
    required: 'Please enter a date of birth',
    invalidDate: 'Please enter a valid date'
  },
  isWellmarkMember: {
    required: 'Please select Yes or No',
  },
  wellmarkMemberSSN: {
    required: 'Please enter the last 4 numbers of your SSN',
    minlength: 'Please enter a valid last 4 numbers of the SSN',
    maxlength: 'Please enter a valid last 4 numbers of the SSN',
    pattern: 'Please enter a valid last 4 numbers of the SSN'
  },
  wellmarkId: {
    required: 'Please enter your Wellmark Id'
  },
  ssn: {
    required: 'Please enter the Social Security Number',
    pattern: 'Please enter a valid Social Security Number (XXX-XX-XXXX)'
  },
  identifier: {
    required: 'Please choose an option',
  },
  requestedExpirationDate: {
    required: 'Please the requested expiration date',
    invalidDate: 'Please enter a valid date'
  },
  emailAddress: {
    required: 'Please enter the email address',
    pattern: 'Please enter a valid email address'
  },
  addressLine1: {
    required: 'Please enter the address',
  },
  addressLine2: {
  },
  zipCode: {
    required: 'Please enter a ZIP code',
    pattern: 'Please enter a valid ZIP code'
  },
  cityState: {
    required: 'Please select a city and state',
  },
};

export const PERSONAL_PREP_FORM_LAST4SSN_ERRORS =
  Object.assign({}, PERSONAL_PREP_FORM_ERRORS, {
    ssn: {
      required: 'Please enter the Last 4 numbers of the Social Security Number',
      minlength: 'Please enter a valid last 4 numbers of the SSN',
      maxlength: 'Please enter a valid last 4 numbers of the SSN',
      pattern: 'Please enter a valid last 4 numbers of the SSN'
    },
  });

export const FINALIZE_FORM_ERRORS = {
  certify: {
    required: 'Please confirm certification'
  },
  firstName: {
    required: 'Please enter the first name'
  },
  lastName: {
    required: 'Please enter the last name'
  },
  reCaptchaKey: {
    required: 'Please toggle the reCaptcha'
  }
};

// Patterns
export const EMAIL_PATTERN = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
export const RELATIONSHIP_PATTERN = /(Legal Guardian)|(Power of Attorney)|(Parent)/;
export const SSN_PATTERN = /^[0-9]{3}-[0-9]{2}-[0-9]{4}$/;
export const LAST_FOUR_DIGITS_SSN_PATTERN = /^[0-9]{4}$/;
export const ZIP_PATTERN = /^\d{5}(?:[-\s]\d{4})?$/;
export const WELLMARK_ID_PATTERN = /^[a-zA-Z]\d{8}$/;
// Date format
export const DATE_FORMAT = 'M/D/YYYY';
