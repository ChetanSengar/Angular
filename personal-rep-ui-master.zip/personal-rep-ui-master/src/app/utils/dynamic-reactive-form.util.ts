import { FormControl, FormGroup } from '@angular/forms';

/**
 * Dynamic reactive form, gives methods to manipulate a form group
 */
export class DynamicReactiveForm {
  /**
   * create dynamic reactive form with the given form group
   * @param form the form group
   */
  constructor(private form: FormGroup) {
  }

  /**
   * Add form controls
   * @param controls the form controls
   */
  addFormControls(controls: any): void {
    Object.keys(controls).forEach(name => {
      this.form.addControl(name, new FormControl(...controls[name]));
    });
  }

  /**
   * Remove form controls
   * @param controls the form controls name list
   */
  removeFromControls(controls: string[]): void {
    controls.forEach(name => {
      this.form.removeControl(name);
    });
  }
}
