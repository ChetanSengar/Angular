import { ApplicationStep } from '@wellmark/wm-lib-ux';
import { FormGroup } from '@angular/forms';

/**
 * Progress stepper manager
 */
export class StepperManager {
  private steps: ApplicationStep[];
  private stepsForms: Step[];
  // current index
  private current: number;

  /**
   * Create a stepper manager with the provided steps (the order is important)
   * @param stepsNames the step names
   */
  constructor(stepsNames: Step[]) {
    this.steps = stepsNames.map((step, i) => {
      return {
        order: i,
        stepName: step.stepName,
        isCurrent: !i,
        isInProgress: !i
      };
    });

    this.current = 0;

    this.stepsForms = [...stepsNames];
  }

  /**
   * Reset steps to default
   * @param steps the steps
   */
  static resetSteps(steps: ApplicationStep[]): ApplicationStep[] {
    return steps.map(step => this.resetStep(step));
  }

  /**
   * Reset individual step
   * @param step the step
   */
  static resetStep(step: ApplicationStep): ApplicationStep {
    return Object.assign(
      {},
      {...step},
      {isCurrent: false, isInProgress: false}
    );
  }

  /**
   * get steps
   */
  getSteps(): ApplicationStep[] {
    return this.steps;
  }

  /**
   * Go to next step if possible
   */
  next(): ApplicationStep[] {
    if (this.stepsForms[this.current].form.valid && this.current + 1 < this.steps.length) {
      this.steps = StepperManager.resetSteps(this.steps);
      this.current++;
      const step = this.steps[this.current];
      this.steps[this.current] = Object.assign({}, step, {
        isCurrent: true,
        isInProgress: true
      });
      return this.steps;
    } else if (this.stepsForms[this.current].form.invalid) {
      this.stepsForms[this.current]?.validationFunction();
    }
    return this.steps;
  }

  /**
   * Go to previous step if possible
   */
  previous(): ApplicationStep[] {
    if (this.current) {
      this.steps = StepperManager.resetSteps(this.steps);
      this.current--;
      const step = this.steps[this.current];
      this.steps[this.current] = Object.assign({}, step, {
        isCurrent: true,
        isInProgress: true
      });
      return this.steps;
    }
    return this.steps;
  }

  /**
   * Switch to the given step if possible
   * @param selectedStep the given selected step
   */
  switchStep(selectedStep: ApplicationStep): ApplicationStep[] {
    const index = this.steps.findIndex(e => e.stepName === selectedStep.stepName);
    if (index !== -1 && index !== this.current) {
      const invalidIndex = this.stepsForms.findIndex((e, i) => {
        return e.form.invalid && i < index;
      });

      if (invalidIndex !== -1) {
        this.stepsForms[invalidIndex].validationFunction();
        return this.steps;
      }

      this.steps = StepperManager.resetSteps(this.steps);
      const step = this.steps[index];
      this.steps[index] = Object.assign({}, step, {
        isCurrent: true,
        isInProgress: true
      });
      this.current = this.steps[index].order;
      return this.steps;
    }

    return this.steps;
  }
}

export interface Step {
  stepName: string;
  form: FormGroup;
  validationFunction?: () => void;
}
