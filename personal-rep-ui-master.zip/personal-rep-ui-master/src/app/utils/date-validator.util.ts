import { FormControl } from '@angular/forms';
import * as moment from 'moment';
import { DATE_FORMAT } from '../config';

/**
 * generate date validator
 * @param format the given format to validate with
 */
export function DateValidator(format = DATE_FORMAT): any {
  return (control: FormControl): { [key: string]: any } => {
    const val = moment(control.value, format, true);

    if (!val.isValid()) {
      return { invalidDate: true };
    }

    return null;
  };
}
