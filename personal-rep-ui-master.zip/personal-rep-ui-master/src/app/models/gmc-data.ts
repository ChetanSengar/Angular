import { SignerInformation } from './signer-information';
import { MemberInformation } from './member-information';
import { RepInformation } from './rep-information';

export interface GmcData {
  singerInformation: SignerInformation;
  memberInformation: MemberInformation;
  repInformation: RepInformation;
}
