export interface SendEmailRequest {
  destination: Destination;
  fromAddress: string;
  messageType: string;
  overrideBusinessHours: boolean;
  subject: string;
  attachments: Attachment[];
  content: Content;
  relatedDocuments?: RelatedDocument[];
  correlationId?: string;
  campaignName?: string;
  party?: Party;
}

export interface Destination {
  toAddresses:	string;
  ccAddresses?:	string;
  bccAddresses?:	string;
}

export interface Attachment {
  content:	string;
  contentType: string;
  filename:	string;
}

export interface RelatedDocument {
  locationId:	string;
  documentKey:	string;
  filename:	string;
}

export interface Content {
  body: string;
  communicationInformation?: CommunicationInformation;
}

export interface CommunicationInformation {
  communicationName:	string;
  data: any;
  type:	string;
}

export interface Party {
  partyType:	string;
  individualOperationalIdentifier:	string;
  providerNumber:	string;
  agentNumber:	string;
  agencyNumber:	string;
  accountKey:	string;
  name:	string;
}
