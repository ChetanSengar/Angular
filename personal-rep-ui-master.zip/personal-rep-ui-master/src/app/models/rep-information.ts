export interface RepInformation {
  firstName:	string;
  lastName:	string;
  dateOfExpiration:	string;
  addressLine1:	string;
  addressLine2:	string;
  city:	string;
  state:	string;
  zipCode:	string;
  emailAddress:	string;
}
