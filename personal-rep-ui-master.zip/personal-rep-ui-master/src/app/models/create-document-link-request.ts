import { GmcData } from './gmc-data';

export interface CreateDocumentLinkRequest {
  project: string;
  documentTtl: number;
  gmcData: GmcData;
}
