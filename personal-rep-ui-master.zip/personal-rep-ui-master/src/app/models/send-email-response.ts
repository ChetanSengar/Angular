export type SendEmailResponse = SendEmailResponseInstance[];

export interface SendEmailResponseInstance {
  interactionIdentifier:	string;
  pendingUntilBusinessHours:	boolean;
}
