export interface Error {
  statusCode: number;
  error: string;
  message: string[];
  Errors: string[];
}
