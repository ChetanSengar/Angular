export type FormType = 'appointment' | 'removal';
