export type SignerRelation = 'Self' | 'Legal Guardian' |
  'Power of Attorney' |
  'Parent';

export interface CityState {
  city: string;
  state: string;
}

export interface SignerInformation {
  signerRelation: SignerRelation;
  firstName: string;
  lastName: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  zipCode: string;
  emailAddress: string;
}

export interface SignedSignerInformation extends SignerInformation {
  eSigAttestation: SigAttestation;
}

export interface SigAttestation {
  firstName: string;
  lastName: string;
}
