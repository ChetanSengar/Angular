export interface MemberInformation {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  addressLine1: string;
  addressLine2: string;
  ssn: string;
  city: string;
  state: string;
  zipCode: string;
  emailAddress: string;
}
