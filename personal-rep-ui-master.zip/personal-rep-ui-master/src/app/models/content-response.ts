export interface ContentResponseInstance {
  uid:	string;
  link:	string;
  type:	string;
  source:	string;
  publishedDate:	string;
  title:	string;
  fullText:	string;
  targetAudience: TargetAudience;
}

export type ContentResponse = ContentResponseInstance[];

export interface TargetAudience {
  roles: string[];
  states: string[];
  groupSizes: string[];
  fundingUnits: string[];
}
