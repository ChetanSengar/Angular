export interface CreateDocumentLinkResponse {
  attributes:	Attribute;
  log: string;
  source:	Source;
  jobId: string;
}

export interface Attribute {
  additionalProp1: any;
}

export interface Source {
  url: string;
  fileName: string;
}
