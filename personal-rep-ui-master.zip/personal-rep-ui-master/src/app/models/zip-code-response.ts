export interface ZipCodeResponse {
  _id:	string;
  zipCodeTypeKey:	number;
  primaryPhoneAreaCode:	string;
  ratingRegionCode:	string;
  ratingRegionDescription:	string;
  sourceSystemIdentifier:	number;
  createDateTime:	string;
  createInstanceIdentifier:	number;
  createProcessIdentifier:	number;
  dialectEventIdentifier:	string;
  eventProcessMethodCode:	string;
  md5ChecksumValue:	string;
  rawEventIdentifier:	string;
  updateDateTime:	string;
  updateInstanceIdentifier:	number;
  actionCode:	string;
  county:	County[];
  zipCodeCity:	ZipCodeCity[];
}

export interface County {
  _id:	string;
  nationalCountyCode:	string;
  addressRecordCount:	string;
  nationalCountyName:	string;
  nationalStateCode:	string;
  stateCode:	string;
  stateName:	string;
  contiguousCountyFlag:	string;
  multipleCountyFlag:	string;
  prevalentCountyFlag:	string;
  sourceSystemIdentifier:	string;
  createDateTime:	string;
  createInstanceIdentifier:	number;
  createProcessIdentifier:	number;
  dialectEventIdentifier:	string;
  eventProcessMethodCode:	string;
  md5ChecksumValue:	string;
  rawEventIdentifier:	string;
  updateDateTime:	string;
  updateInstanceIdentifier:	number;
  actionCode:	string;
}

export interface ZipCodeCity {
  _id:	string;
  cityName:	string;
  preferredCityKey:	number;
  sourceSystemIdentifier:	number;
  createDateTime:	string;
  createInstanceIdentifier:	number;
  createProcessIdentifier:	number;
  dialectEventIdentifier:	string;
  eventProcessMethodCode:	string;
  md5ChecksumValue:	string;
  rawEventIdentifier:	string;
  updateDateTime:	string;
  updateInstanceIdentifier:	number;
  actionCode:	string;
}

export interface CityStatePair {
  city: string;
  state: string;
}
