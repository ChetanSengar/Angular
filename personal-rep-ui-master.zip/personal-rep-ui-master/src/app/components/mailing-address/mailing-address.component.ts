import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { merge, Observable, of } from 'rxjs';
import { filter, finalize, map, switchMap, tap } from 'rxjs/operators';
import { ZIP_PATTERN } from '../../config';
import { ZipService } from '../../services/api/zip.service';
import { CityStatePair, ZipCodeResponse } from '../../models/zip-code-response';
import { FormType } from '../../models/form-type';

@Component({
  selector: 'app-mailing-address',
  templateUrl: './mailing-address.component.html',
  styleUrls: ['./mailing-address.component.scss']
})
export class MailingAddressComponent implements OnInit {

  @Input() form: FormGroup;

  // is load cities and states given a zip code
  loadingZips: boolean;

  cityState$: Observable<CityStatePair[]>;
  constructor(private zipService: ZipService) {
  }

  ngOnInit(): void {
    this.cityState$ = this.form.get('zipCode').valueChanges // when zip code changes
      .pipe(
        tap(() => {
          this.loadingZips = true;                         // side effect: is loading data
        }),
        switchMap(input => {                        // switch the latest zip code event
          if (ZIP_PATTERN.test(input)) {                   //      changes and map input to network request
            return this.zipService.getZipCodeInfo(input);
          } else {
            this.form.get('cityState').patchValue('');
            return of(null);
          }
        }),
        map((response: ZipCodeResponse) => {  // map zip code response to city state array
          return response
            ? response.county
            .map(({stateName}, i) => (
                {state: stateName, city: response.zipCodeCity[i].cityName}
              )
            )
            : [];
        }),
        tap(array => {        // side effect: patch value in case one options available
          if (array.length === 1) {
            this.form.get('cityState').patchValue(this.stringify(array[0]));
          }
        }),
        map(response => {   // map: handle one option case
          if (response.length === 1) {
            return [];
          }
          return response;
        }),
        tap(() => {           // side effect: stop loading
          this.loadingZips = false;
        })
      );

    const zipCode = this.form.value.zipCode;
    if (zipCode && ZIP_PATTERN.test(zipCode)) { // if zip code available
      this.cityState$ = merge(
        this.zipService
          .getZipCodeInfo(zipCode)              // network request
          .pipe(
            map((response: ZipCodeResponse) => {  // map response to options array
              return response.county
                .map(({stateName}, i) => (
                    {state: stateName, city: response.zipCodeCity[i].cityName}
                  )
                );
            }),
            tap(array => {    // side effect: one option case
              if (array.length === 1) {
                this.form.get('cityState').patchValue(this.stringify(array[0]));
              }
            }),
            map(response => {   // map result: handle one option case
              if (response.length === 1) {
                return [];
              }
              return response;
            })
          ),
        this.cityState$);
    }
  }

  /**
   * Stringify a city state pair
   * @param cityState the city state pair
   */
  stringify(cityState: CityStatePair): string {
    return JSON.stringify(cityState);
  }

  /**
   * Parse city state pair
   * @param str the string to parse
   */
  parseCityState(str: string): CityStatePair {
    return JSON.parse(str);
  }
}
