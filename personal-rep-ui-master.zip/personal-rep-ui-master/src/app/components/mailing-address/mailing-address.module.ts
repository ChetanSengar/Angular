import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MailingAddressComponent } from './mailing-address.component';
import { WellmarkFieldModule, WellmarkRadioModule } from '@wellmark/wm-lib-ux';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
    declarations: [MailingAddressComponent],
    exports: [
        MailingAddressComponent
    ],
    imports: [
        CommonModule,
        WellmarkFieldModule,
        WellmarkRadioModule,
        ReactiveFormsModule
    ]
})
export class MailingAddressModule { }
