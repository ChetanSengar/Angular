import { Component, Input, OnInit } from '@angular/core';
import { SelectItem } from '@wellmark/wm-lib-ux';
import { FormGroup } from '@angular/forms';
import { FormType } from '../../../models/form-type';
import * as moment from 'moment';
import { DATE_FORMAT } from '../../../config';
import { strict } from 'assert';

@Component({
  selector: 'app-personal-representative-information',
  templateUrl: './personal-representative-information.component.html',
  styleUrls: ['./personal-representative-information.component.scss']
})
export class PersonalRepresentativeInformationComponent implements OnInit {

  isPersonalRepresentative: SelectItem[] = [
    { label: 'Yes', value: true },
    { label: 'No', value: false }
  ];

  isWellmarkMember: SelectItem[] = [
    { label: 'Yes', value: true },
    { label: 'No', value: false }
  ];

  @Input() personalRepresentativeForm: FormGroup;

  @Input() memberForm: FormGroup;

  @Input() formType: FormType;

  constructor() { }

  ngOnInit(): void {
    if (this.isLessThan18 && this.formType === 'appointment') {
      this.personalRepresentativeForm
        .get('requestedExpirationDate')
        .patchValue(
          moment(this.memberForm.value.dateOfBirth, DATE_FORMAT, true)
            .add(18, 'year')
            .format('MM/DD/YYYY')
        );
    }
  }

  /**
   * <code>true</code>: when less than 18
   */
  get isLessThan18(): boolean {
    return moment(this.memberForm.value.dateOfBirth, DATE_FORMAT, true)
      .diff(new Date(), 'years', true) < 18;
  }
}
