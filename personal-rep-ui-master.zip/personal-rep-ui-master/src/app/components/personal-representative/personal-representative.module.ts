import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PersonalRepresentativeComponent } from './personal-representative.component';
import {
  WellmarkAlertModule,
  WellmarkCardModule,
  WellmarkFieldModule,
  WellmarkRadioModule,
  WellmarkSplitButtonModule
} from '@wellmark/wm-lib-ux';
import { PersonalRepresentativeInformationComponent } from './personal-representative-information/personal-representative-information.component';
import { MailingAddressModule } from '../mailing-address/mailing-address.module';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [PersonalRepresentativeComponent, PersonalRepresentativeInformationComponent],
  exports: [
    PersonalRepresentativeComponent
  ],
  imports: [
    CommonModule,
    WellmarkCardModule,
    WellmarkFieldModule,
    WellmarkRadioModule,
    MailingAddressModule,
    WellmarkSplitButtonModule,
    ReactiveFormsModule,
    WellmarkAlertModule
  ]
})
export class PersonalRepresentativeModule { }
