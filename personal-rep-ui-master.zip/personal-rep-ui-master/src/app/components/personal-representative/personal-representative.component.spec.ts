import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalRepresentativeComponent } from './personal-representative.component';

describe('PersonalRepresentativeComponent', () => {
  let component: PersonalRepresentativeComponent;
  let fixture: ComponentFixture<PersonalRepresentativeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalRepresentativeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
