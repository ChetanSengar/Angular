import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { DynamicReactiveForm } from '../../utils/dynamic-reactive-form.util';
import {
  EMAIL_PATTERN, LAST_FOUR_DIGITS_SSN_PATTERN,
  SSN_PATTERN, WELLMARK_ID_PATTERN, ZIP_PATTERN
} from '../../config';
import { DateValidator } from '../../utils/date-validator.util';
import { distinctUntilChanged, filter } from 'rxjs/operators';
import { FormService, WellmarkError } from '@wellmark/wm-lib-ux';
import { Observable } from 'rxjs';
import { FormType } from '../../models/form-type';
import * as moment from 'moment';

@Component({
  selector: 'app-personal-representative',
  templateUrl: './personal-representative.component.html',
  styleUrls: ['./personal-representative.component.scss']
})
export class PersonalRepresentativeComponent implements OnInit {

  @Input() personalRepresentativeForm: FormGroup;

  @Input() subjectForm: FormGroup;

  @Input() memberForm: FormGroup;

  @Input() formType: FormType;

  @Output() previous = new EventEmitter();

  @Output() next = new EventEmitter();

  errors$: Observable<WellmarkError[]>;

  dynamicForm: DynamicReactiveForm;

  constructor(private formService: FormService) {
  }

  ngOnInit(): void {
    this.formService.clearErrors();
    this.errors$ = this.formService.errors$;
    this.dynamicForm =
      new DynamicReactiveForm(this.personalRepresentativeForm);
    if (this.formType === 'appointment') {
      this.addAppointmentFormConfig();
    } else {
      this.addRemovalFormConfig();
    }
  }

  /**
   * Add removal form configuration
   */
  addRemovalFormConfig(): void {
    this.dynamicForm.addFormControls({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      requestedExpirationDate: [moment(new Date()).format('MM/DD/YYYY'), DateValidator()],
    });
  }

  /**
   * Add appointment form configuration
   */
  addAppointmentFormConfig(): void {
    this.dynamicForm.addFormControls({
      isAppointingPersonalRepresentative: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dateOfBirth: ['',
        [
          Validators.required,
          DateValidator()
        ]
      ],
      isWellmarkMember: ['', Validators.required],
      identifier: ['', Validators.required],
      requestedExpirationDate: ['', DateValidator()],
      emailAddress: ['',
        [
          Validators.required,
          Validators.pattern(EMAIL_PATTERN)
        ]
      ],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      cityState: ['', Validators.required],
      zipCode: ['',
        [
          Validators.required,
          Validators.pattern(ZIP_PATTERN)
        ]
      ],
    });

    this.personalRepresentativeForm
      .get('isAppointingPersonalRepresentative')
      .valueChanges
      .pipe(
        filter(v => typeof v === 'boolean')
      ).subscribe(v => {
      if (v) {
        this.personalRepresentativeForm.get('firstName')
          .patchValue(this.subjectForm.value.firstName);
        this.personalRepresentativeForm.get('lastName')
          .patchValue(this.subjectForm.value.lastName);
        this.personalRepresentativeForm.get('emailAddress')
          .patchValue(this.subjectForm.value.emailAddress);
      } else {
        this.personalRepresentativeForm.get('firstName')
          .patchValue('');
        this.personalRepresentativeForm.get('lastName')
          .patchValue('');
        this.personalRepresentativeForm.get('emailAddress')
          .patchValue('');
      }
    });

    this.personalRepresentativeForm
      .get('isWellmarkMember')
      .valueChanges
      .pipe(distinctUntilChanged())
      .subscribe(isWellmarkMember => {
          if (typeof isWellmarkMember !== 'boolean') {
            return;
          } else if (isWellmarkMember) {
            this.dynamicForm.addFormControls({
              wellmarkMemberSSN: ['',
                [
                  Validators.required,
                  Validators.pattern(LAST_FOUR_DIGITS_SSN_PATTERN)
                ]
              ],
              wellmarkId: ['', [Validators.required, Validators.pattern(WELLMARK_ID_PATTERN)]]
            });
          } else {
            this.dynamicForm.removeFromControls(['wellmarkMemberSSN', 'wellmarkId']);
          }
        }
      );

    this.personalRepresentativeForm
      .get('identifier')
      .valueChanges
      .pipe(distinctUntilChanged())
      .subscribe(identifier => {
        if (identifier === 'ssn') {
          this.dynamicForm.removeFromControls(['ssn']);
          this.dynamicForm.addFormControls({
            ssn: ['',
              [
                Validators.required,
                Validators.pattern(SSN_PATTERN)
              ]
            ]
          });
        } else if (identifier === 'last4ssn') {
          this.dynamicForm.removeFromControls(['ssn']);
          this.dynamicForm.addFormControls({
            ssn: ['',
              [
                Validators.required,
                Validators.pattern(LAST_FOUR_DIGITS_SSN_PATTERN)
              ]
            ]
          });
        }
      });
  }

  setFocus(fieldId: string): void {
    this.formService.focusField(fieldId);
  }
}
