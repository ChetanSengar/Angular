import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuccessComponent } from './success.component';
import { WellmarkCardModule } from '@wellmark/wm-lib-ux';
import { ContactModule } from '../contact/contact.module';



@NgModule({
    declarations: [SuccessComponent],
    exports: [
        SuccessComponent
    ],
    imports: [
        CommonModule,
        WellmarkCardModule,
        ContactModule
    ]
})
export class SuccessModule { }
