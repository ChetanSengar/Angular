import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { DynamicReactiveForm } from '../../utils/dynamic-reactive-form.util';
import { Observable } from 'rxjs';
import { FormService, WellmarkError } from '@wellmark/wm-lib-ux';
import { FormType } from '../../models/form-type';

@Component({
  selector: 'app-finalize',
  templateUrl: './finalize.component.html',
  styleUrls: ['./finalize.component.scss']
})
export class FinalizeComponent implements OnInit {

  @Input() finalizeForm: FormGroup;

  @Input() formType: FormType;

  @Output() previous = new EventEmitter();

  @Output() submitForms = new EventEmitter();

  dynamicForm: DynamicReactiveForm;

  errors$: Observable<WellmarkError[]>;

  constructor(private formService: FormService) { }

  ngOnInit(): void {
    this.formService.clearErrors();
    this.errors$ = this.formService.errors$;
    this.dynamicForm = new DynamicReactiveForm(this.finalizeForm);
    this.dynamicForm.addFormControls({
      certify: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      reCaptchaKey: [null, Validators.required]
    });
  }

  /**
   * Set view focus to the given field identifier
   * @param fieldId te field identifier
   */
  setFocus(fieldId: string): void {
    this.formService.focusField(fieldId);
  }

  /**
   * Handle resolving reCaptcha key
   * @param key the reCaptcha public key
   */
  resolveKey(key: string): void {
    this.finalizeForm.get('reCaptchaKey').patchValue(key);
  }
}
