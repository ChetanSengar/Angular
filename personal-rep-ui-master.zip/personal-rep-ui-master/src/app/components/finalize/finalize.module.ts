import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FinalizeComponent } from './finalize.component';
import { WellmarkAlertModule, WellmarkCardModule, WellmarkCheckboxModule, WellmarkFieldModule } from '@wellmark/wm-lib-ux';
import { ReactiveFormsModule } from '@angular/forms';
import { RECAPTCHA_SETTINGS, RecaptchaModule, RecaptchaSettings } from 'ng-recaptcha';
import { RECAPTCHA_KEY } from 'src/reCAPTCHA-key';


@NgModule({
    declarations: [FinalizeComponent],
    exports: [
        FinalizeComponent
    ],
    imports: [
        CommonModule,
        WellmarkCardModule,
        WellmarkFieldModule,
        ReactiveFormsModule,
        WellmarkCheckboxModule,
        RecaptchaModule,
        WellmarkAlertModule
    ],
  providers: [
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: { siteKey: RECAPTCHA_KEY } as RecaptchaSettings,
    },
  ],
})
export class FinalizeModule { }
