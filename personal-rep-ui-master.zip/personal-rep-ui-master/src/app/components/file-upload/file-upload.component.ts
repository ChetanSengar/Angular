import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { DocumentUpload } from './document-upload';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {
  @ViewChild('fileSelector') fileSelector: any;
  @Input() inputId: string;
  @Input() maxFileSizeBytes: number;
  @Input() allowedFileTypes: string[];
  @Input() existingDocument: DocumentUpload;
  @Output() documentUploaded = new EventEmitter<DocumentUpload>();
  @Output() disallowedFileType = new EventEmitter<string>();
  @Output() maxFileSizeExceeded = new EventEmitter<string>();
  @Output() documentDeleted = new EventEmitter<DocumentUpload>();
  allowedTypesString = '';
  uploadedDocument: DocumentUpload = null;
  isIE: boolean;

  constructor(private sanitizer: DomSanitizer) { }
  ngOnInit(): void {
    this.isIE = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);

    if (this.existingDocument) {
      this.uploadedDocument = this.existingDocument;
    }

    if (this.allowedFileTypes && this.allowedFileTypes.length > 0) {
      const tempFileTypeArray: string[] = [];
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < this.allowedFileTypes.length; i++) {
        tempFileTypeArray.push(`.${this.allowedFileTypes[i]}`);
      }
      this.allowedTypesString = tempFileTypeArray.join();
    }
  }

  /**
   * handle file upload
   * @param fileInput the file input
   */
  handleUpload(fileInput): void {
    if (fileInput.target.files && fileInput.target.files[0]) {
      const doc: DocumentUpload = {};
      const reader = new FileReader();
      doc.fileName = fileInput.target.files[0].name;
      doc.fileType = doc.fileName.split('.').pop();
      if (this.allowedFileTypes.findIndex((f) => f.toUpperCase() === doc.fileType.toUpperCase()) === -1) {
        this.disallowedFileType.emit(`File type not allowed:  ${doc.fileType.toUpperCase()}`);
        return;
      }
      doc.fileSizeBytes = fileInput.target.files[0].size;
      if (doc.fileSizeBytes > this.maxFileSizeBytes) {
        this.maxFileSizeExceeded.emit(`File size of ${this.maxFileSizeBytes} exceeded.  Actual file size: ${doc.fileSizeBytes}`);
        return;
      }
      reader.onloadend = (e) => {
        doc.byteString = btoa((reader.result as string).split(',')[1]);
        doc.dataUrl = this.sanitizer.bypassSecurityTrustResourceUrl(reader.result as string);
        this.fileSelector.nativeElement.value = '';
        // this.uploadedDocument = doc;
        this.documentUploaded.emit(doc);
      };
      reader.readAsDataURL(fileInput.target.files[0]);
    }
  }

  /**
   * handle delete document
   */
  deleteDocument(): void {
    this.documentDeleted.emit(this.uploadedDocument);
  }

}
