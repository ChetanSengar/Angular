import { SafeResourceUrl } from '@angular/platform-browser';

export interface DocumentUpload {
  byteString?: string;
  dataUrl?: SafeResourceUrl;
  fileType?: string;
  fileName?: string;
  fileSizeBytes?: number;
  accepted?: boolean;
}
