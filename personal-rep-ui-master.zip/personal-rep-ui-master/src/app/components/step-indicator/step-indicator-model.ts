export interface ApplicationStep {
  order: number;
  stepName: string;
  isCurrent: boolean;
  isInProgress: boolean;
}
