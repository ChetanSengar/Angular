import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WellmarkStepIndicatorComponent } from './step-indicator.component';

@NgModule({
  declarations: [WellmarkStepIndicatorComponent],
  imports: [
    CommonModule
  ],
  exports: [WellmarkStepIndicatorComponent]
})
export class WellmarkStepIndicatorModule { }
