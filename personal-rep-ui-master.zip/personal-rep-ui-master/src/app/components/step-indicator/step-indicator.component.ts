import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

import { ApplicationStep } from './step-indicator-model';

@Component({
  selector: 'app-step-indicator',
  templateUrl: './step-indicator.component.html',
  styleUrls: ['./step-indicator.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WellmarkStepIndicatorComponent implements OnInit {
  @Input() steps: ApplicationStep[];
  @Output() stepSelected = new EventEmitter<ApplicationStep>();
  private keys = {
    left: 37,
    right: 39,
    space: 32,
    tab: 9
  };
  constructor() { }

  ngOnInit(): void {
    if (!this.steps) {
      this.steps = [{order: 0,
        stepName: 'default',
        isCurrent: true,
        isInProgress: true}];
    }
    this.steps = this.steps.sort((a, b) => a.order - b.order);
  }

  /**
   * Get area owns
   */
  getOwns(): void {
    this.steps.map((step) => `tabNav${step.order}`).join(' ');
  }

  /**
   * get css class denoting the current status given the step
   * @param step the step
   */
  statusClass(step: ApplicationStep): string {
    const currentStep = this.steps.find((s) => s.isCurrent);
    if (step.order < currentStep.order) {
      return 'complete';
    }
    if (step.isCurrent && step.isInProgress) {
      return 'partial';
    }
    if (step.isCurrent && !step.isInProgress) {
      return 'initial';
    }
    return null;
  }

  /**
   * click event step handler
   * @param step the step clicked
   */
  clicked(step: ApplicationStep): void {
    this.stepSelected.emit(step);
  }

  /**
   * On Key event handler
   * @param event the event
   * @param step the step
   */
  onKey(event, step: ApplicationStep): void {
    const tabItems = event.target.parentElement.parentElement;
    const numbOfTabs: number = tabItems.childElementCount;
    const index: number = this.findTabIndex(tabItems);

    if (event.keyCode !== this.keys.left &&
      event.keyCode !== this.keys.right &&
      event.keyCode !== this.keys.tab &&
      event.keyCode !== this.keys.space) {
      return;
    }

    // Left arrow keypress
    if (event.keyCode === this.keys.left) {
      if (index !== 0) {
        tabItems.children[index - 1].children[3].focus();
      } else {
        tabItems.children[numbOfTabs - 1].children[3].focus();
      }
    }

    // Right arrow keypress
    if (event.keyCode === this.keys.right) {
      if (index !== (numbOfTabs - 1)) {
        tabItems.children[index + 1].children[3].focus();
      } else {
        tabItems.children[0].children[3].focus();
      }
    }

    // Activate using spacebar
    if (event.keyCode === this.keys.space) {
      this.stepSelected.emit(step);
      event.preventDefault();
    }
  }

  findTabIndex(tabs): number {
    let index = -1;
    // tslint:disable-next-line:no-increment-decrement
    for (let i = 0; i < tabs.children.length; i++) {
      if (tabs.children[i].children[3] === document.activeElement) {
        index = i;
        break;
      }
    }
    return index;
  }
}
