import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellmarkStepIndicatorComponent } from './step-indicator.component';

describe('WmStepIndicatorComponent', () => {
  let component: WellmarkStepIndicatorComponent;
  let fixture: ComponentFixture<WellmarkStepIndicatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WellmarkStepIndicatorComponent]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WellmarkStepIndicatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
