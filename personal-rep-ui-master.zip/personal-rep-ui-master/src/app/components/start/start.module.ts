import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StartComponent } from './start.component';
import { WellmarkCardModule } from '@wellmark/wm-lib-ux';
import { ContactModule } from '../contact/contact.module';



@NgModule({
    declarations: [StartComponent],
    exports: [
        StartComponent
    ],
    imports: [
        CommonModule,
        WellmarkCardModule,
        ContactModule
    ]
})
export class StartModule { }
