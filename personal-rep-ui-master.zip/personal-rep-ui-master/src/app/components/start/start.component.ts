import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormType } from '../../models/form-type';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.scss']
})
export class StartComponent implements OnInit {

  @Input() formType: FormType;
  @Output() goToForm = new EventEmitter<void>();

  constructor() { }

  ngOnInit(): void {
  }
}
