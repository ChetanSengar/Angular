import { Component, Input, OnInit } from '@angular/core';
import { DocumentUpload } from '@wellmark/wm-lib-ux';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-personal-representative-information',
  templateUrl: './personal-representative-information.component.html',
  styleUrls: ['./personal-representative-information.component.scss']
})
export class PersonalRepresentativeInformationComponent implements OnInit {

  document: DocumentUpload;

  constructor() { }

  @Input() subjectForm: FormGroup;

  ngOnInit(): void {
    this.document = this.subjectForm.value.documentation;
  }

  /**
   * Handle document selection
   * @param document the document selected
   */
  handleDocumentUpload(document: DocumentUpload): void {
    this.document = document;
    this.subjectForm
      .get('documentation')
      .patchValue(document);
  }

  /**
   * Remove document
   * @param document the removed document
   */
  handleDocumentDeleted(document: DocumentUpload): void {
    this.document = null;
    this.subjectForm
      .get('documentation')
      .patchValue(null);
  }

  /**
   * File selection error
   * @param error the error
   */
  showMessage(error: string): void {
  }
}
