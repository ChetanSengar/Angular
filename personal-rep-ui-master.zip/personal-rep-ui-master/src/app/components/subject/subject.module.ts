import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubjectComponent } from './subject.component';
import {
  FormService,
  FormValidationService, WellmarkAlertModule,
  WellmarkCardModule,
  WellmarkFieldModule,
  WellmarkRadioModule,
  WellmarkSplitButtonModule,
} from '@wellmark/wm-lib-ux';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { PersonalRepresentativeInformationComponent } from './personal-representative-information/personal-representative-information.component';
import { MailingAddressModule } from '../mailing-address/mailing-address.module';
import { SubjectIdentityComponent } from './subject-identity/subject-identity.component';
import { FileUploadModule } from '../file-upload/file-upload.module';


@NgModule({
  declarations: [
    SubjectComponent,
    PersonalRepresentativeInformationComponent,
    SubjectIdentityComponent
  ],
    exports: [
        SubjectComponent,
        PersonalRepresentativeInformationComponent
    ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    WellmarkCardModule,
    WellmarkFieldModule,
    WellmarkRadioModule,
    MailingAddressModule,
    ReactiveFormsModule,
    FileUploadModule,
    WellmarkAlertModule,
    WellmarkSplitButtonModule,
  ],
  providers: [
    FormControl,
    FormService,
    FormValidationService
  ]
})
export class SubjectModule {
}
