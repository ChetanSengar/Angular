import { Component, Input, OnDestroy, OnInit, EventEmitter, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { distinctUntilChanged, map } from 'rxjs/operators';
import { Observable, Subscription } from 'rxjs';
import { DynamicReactiveForm } from '../../utils/dynamic-reactive-form.util';
import { FormService, WellmarkError } from '@wellmark/wm-lib-ux';
import { SignerRelation } from '../../models/signer-information';
import {
  EMAIL_PATTERN,
  RELATIONSHIP_PATTERN, ZIP_PATTERN,
} from '../../config';
import { FormType } from '../../models/form-type';

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.scss']
})
export class SubjectComponent implements OnInit, OnDestroy {

  @Input() subjectForm: FormGroup;

  @Input() formType: FormType;

  @Output() next = new EventEmitter();

  dynamicForm: DynamicReactiveForm;

  relationshipSelected = false;

  formChangesSubscription: Subscription;

  errors$: Observable<WellmarkError[]>;

  constructor(private formService: FormService) {
  }

  ngOnInit(): void {
    this.formService.clearErrors();
    this.errors$ = this.formService.errors$;
    this.dynamicForm = new DynamicReactiveForm(this.subjectForm);
    this.dynamicForm.addFormControls({
        hasPersonalRepresentative: ['', Validators.required]
      }
    );
    this.formChangesSubscription = this.subjectForm.get('hasPersonalRepresentative')
      .valueChanges
      .pipe(
        distinctUntilChanged()
      ).subscribe(hasPersonalRepresentative => {
        if (hasPersonalRepresentative) {
          this.addFormFields();
          this.subjectForm.get('signerRelation')
            .valueChanges
            .pipe(
              map((relation: string) => {
                return RELATIONSHIP_PATTERN.test(`${relation}`);
              })
            )
            .subscribe(selected => {
              this.relationshipSelected = selected;
            });
        } else {
          this.removeFormFields();
          this.relationshipSelected = false;
        }
      });
    this.subjectForm.patchValue(this.subjectForm.value);
  }

  addFormFields(): void {
    this.dynamicForm.addFormControls({
      signerRelation: ['',
        [
          Validators.required,
          Validators.pattern(RELATIONSHIP_PATTERN)
        ]
      ],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      cityState: ['', Validators.required],
      zipCode: ['',
        [
          Validators.required,
          Validators.pattern(ZIP_PATTERN)
        ]
      ],
      emailAddress: [
        '',
        [
          Validators.required,
          Validators.pattern(EMAIL_PATTERN)
        ]
      ],
      documentation: ['', Validators.required],
    });
  }

  removeFormFields(): void {
    this.dynamicForm.removeFromControls([
      'signerRelation',
      'firstName',
      'lastName',
      'addressLine1',
      'addressLine2',
      'cityState',
      'zipCode',
      'emailAddress',
      'documentation',
    ]);
  }

  ngOnDestroy(): void {
    if (this.formChangesSubscription) {
      this.formChangesSubscription.unsubscribe();
    }
  }

  /**
   * Focus on the given field
   * @param fieldId the field identifier
   */
  setFocus(fieldId: string): void {
    this.formService.focusField(fieldId);
  }

  /**
   * returns <code>true</code> has personal representative
   */
  get hasPersonalRepresentative(): boolean {
    return this.subjectForm.value.hasPersonalRepresentative;
  }

  /**
   * returns signer relation to the member
   */
  get signerRelation(): SignerRelation {
    return this.subjectForm.value.signerRelation;
  }
}
