import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectIdentityComponent } from './subject-identity.component';

describe('SubjectIdentityComponent', () => {
  let component: SubjectIdentityComponent;
  let fixture: ComponentFixture<SubjectIdentityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubjectIdentityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubjectIdentityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
