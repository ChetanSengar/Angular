import { Component, Input, OnInit } from '@angular/core';
import { SelectItem } from '@wellmark/wm-lib-ux';
import { FormGroup } from '@angular/forms';
import { FormType } from '../../../models/form-type';

@Component({
  selector: 'app-subject-identity',
  templateUrl: './subject-identity.component.html',
  styleUrls: ['./subject-identity.component.scss']
})
export class SubjectIdentityComponent implements OnInit {

  @Input() subjectForm: FormGroup;

  @Input() formType: FormType;

  isRepresentingOneself: SelectItem[] = [
    { label: 'Yes', value: true },
    { label: 'No', value: false }
  ];

  constructor() { }

  ngOnInit(): void {
  }

  /**
   * return <code>true</code> when having a personal representative
   */
  get hasPersonalRepresentative(): boolean {
    return this.subjectForm.value.hasPersonalRepresentative;
  }

}
