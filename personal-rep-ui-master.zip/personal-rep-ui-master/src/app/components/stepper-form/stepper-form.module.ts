import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StepperFormComponent } from './stepper-form.component';
// import { WellmarkStepIndicatorModule } from '@wellmark/wm-lib-ux';
import { SubjectModule } from '../subject/subject.module';
import { ContactModule } from '../contact/contact.module';
import { PersonalRepresentativeModule } from '../personal-representative/personal-representative.module';
import { MemberModule } from '../member/member.module';
import { FinalizeModule } from '../finalize/finalize.module';
import { SuccessModule } from '../success/success.module';
import { WellmarkStepIndicatorModule } from '../step-indicator/step-indicator.module';

@NgModule({
  declarations: [StepperFormComponent],
  exports: [
    StepperFormComponent
  ],
    imports: [
        CommonModule,
        SubjectModule,
        ContactModule,
        PersonalRepresentativeModule,
        MemberModule,
        FinalizeModule,
        SuccessModule,
        WellmarkStepIndicatorModule,
    ]
})
export class StepperFormModule { }
