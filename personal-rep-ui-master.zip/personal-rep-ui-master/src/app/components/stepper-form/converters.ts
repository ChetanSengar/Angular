import { FormGroup } from '@angular/forms';
import { SignedSignerInformation, SignerInformation } from '../../models/signer-information';
import { MemberInformation } from '../../models/member-information';
import { CityStatePair } from '../../models/zip-code-response';
import { RepInformation } from '../../models/rep-information';
import { SendEmailRequest } from '../../models/send-email-request';
import { FormType } from '../../models/form-type';

export function getUnsignedSignerInformation({ value }: FormGroup): SignerInformation {
  const cityStatePair: CityStatePair = JSON.parse(value.cityState);
  return {
    signerRelation: value.hasPersonalRepresentative ? value.signerRelation : 'Self',
    firstName: value.firstName,
    lastName: value.lastName,
    addressLine1: value.addressLine1,
    addressLine2: value.addressLine2,
    city: cityStatePair.city,
    state: cityStatePair.state,
    zipCode: value.zipCode,
    emailAddress: value.emailAddress
  };
}

export function getSignedSignerInformation(
  form: FormGroup,
  firstName: string,
  lastName: string
): SignedSignerInformation {
  return {
    ...getUnsignedSignerInformation(form),
    eSigAttestation: {
      firstName,
      lastName
    }
  };
}

export function getMemberInformation({value}: FormGroup): MemberInformation {
  const cityStatePair: CityStatePair = JSON.parse(value.cityState);
  return {
    firstName: value.firstName,
    lastName: value.lastName,
    dateOfBirth: value.dateOfBirth,
    addressLine1: value.addressLine1,
    addressLine2: value.addressLine2,
    ssn: value.ssn,
    city: cityStatePair.city,
    state: cityStatePair.state,
    zipCode: value.zipCode,
    emailAddress: value.emailAddress
  };
}

export function getRepInformation({value}: FormGroup, formType: FormType): RepInformation {
  if (formType === 'appointment') {
    const cityStatePair: CityStatePair = JSON.parse(value.cityState);
    return {
      firstName: value.firstName,
      lastName: value.lastName,
      dateOfExpiration: value.requestedExpirationDate,
      addressLine1: value.addressLine1,
      addressLine2: value.addressLine2,
      city: cityStatePair.city,
      state: cityStatePair.state,
      zipCode: value.zipCode,
      emailAddress: value.emailAddress,
    };
  } else {
    return {
      firstName: value.firstName,
      lastName: value.lastName,
      dateOfExpiration: value.requestedExpirationDate,
      addressLine1: undefined,
      addressLine2: undefined,
      city: undefined,
      state: undefined,
      zipCode: undefined,
      emailAddress: undefined,
    };
  }
}

export function getSendingEmailRequest(
  {value: signer}: FormGroup,
  messageType: string, subject: string, body: string): SendEmailRequest {
  return {
    destination: { toAddresses: 'email@privacy.wellmark.com' },
    fromAddress: signer.emailAddress,
    messageType,
    overrideBusinessHours: true,
    subject,
    attachments: signer.documentation
      ? [{
        content: 'content', // TODO: USE signer.documentation.byteString
        contentType: signer.documentation.fileType,
        filename: signer.documentation.fileName
      }]
      : [],
    content: {
      body
    }
  };
}
