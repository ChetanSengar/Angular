import { AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild, Input } from '@angular/core';
import { ApplicationStep, FormService } from '@wellmark/wm-lib-ux';
import { Step, StepperManager } from '../../utils/stepper-manager.util';
import { FormBuilder, FormGroup } from '@angular/forms';
import {
  DATE_FORMAT,
  FINALIZE_FORM_ERRORS,
  MEMBER_FORM_ERRORS,
  MEMBER_FORM_WITH_WELLMARK_ID_ERRORS,
  PERSONAL_PREP_FORM_ERRORS,
  PERSONAL_PREP_FORM_LAST4SSN_ERRORS,
  SIGNER_FORM_ERRORS,
  SIGNER_FORM_NON_SELECTED_REP_ERRORS
} from '../../config';
import { DocumentService } from '../../services/api/document.service';
import { EmailService } from '../../services/api/email.service';
import { SignerInformation } from '../../models/signer-information';
import { MemberInformation } from '../../models/member-information';
import { RepInformation } from '../../models/rep-information';
import { GmcData } from '../../models/gmc-data';
import { CreateDocumentLinkRequest } from '../../models/create-document-link-request';
import {
  getMemberInformation,
  getRepInformation,
  getSendingEmailRequest,
  getSignedSignerInformation,
  getUnsignedSignerInformation
} from './converters';
import { SendEmailRequest } from '../../models/send-email-request';
import { BehaviorSubject, Observable, zip } from 'rxjs';
import { CreateDocumentLinkResponse } from '../../models/create-document-link-response';
import { SendEmailResponse } from '../../models/send-email-response';
import * as moment from 'moment';

@Component({
  selector: 'app-stepper-form',
  templateUrl: './stepper-form.component.html',
  styleUrls: ['./stepper-form.component.scss']
})
export class StepperFormComponent implements OnInit, AfterContentChecked {

  @ViewChild('stepIndicator') stepIndicator;


  steps: ApplicationStep[];

  subjectForm: FormGroup;

  memberForm: FormGroup;

  personalRepresentativeForm: FormGroup;

  finalizeForm: FormGroup;

  stepperManager: StepperManager;

  createDocumentResponse$: BehaviorSubject<CreateDocumentLinkResponse> = new BehaviorSubject<CreateDocumentLinkResponse>(null);

  documentUrl: string;

  submitForm$: BehaviorSubject<StepperFormSubmitEvent> = new BehaviorSubject<StepperFormSubmitEvent>(null);

  @Input() formType: 'appointment' | 'removal';

  constructor(
    private formBuilder: FormBuilder,
    private formService: FormService,
    private changeDetectorRef: ChangeDetectorRef,
    private documentService: DocumentService,
    private emailService: EmailService,
  ) {
  }

  ngAfterContentChecked(): void {
    this.changeDetectorRef.detectChanges();
  }


  ngOnInit(): void {
    this.subjectForm = this.formBuilder.group({});
    this.memberForm = this.formBuilder.group({});
    this.personalRepresentativeForm = this.formBuilder.group({});
    this.finalizeForm = this.formBuilder.group({});
    const steps: Step[] = [
      { stepName: 'You', form: this.subjectForm, validationFunction: this.validateSubjectForm.bind(this) },
      { stepName: 'Member', form: this.memberForm, validationFunction: this.validateMemberForm.bind(this) },
      {
        stepName: 'Personal Representative',
        form: this.personalRepresentativeForm,
        validationFunction: this.validatePersonalRepForm.bind(this)
      },
      { stepName: 'Finalize', form: this.finalizeForm, validationFunction: this.validateFinalizeForm.bind(this) }
    ];
    this.stepperManager = new StepperManager(steps);
    this.steps = this.stepperManager.getSteps();
    this.createDocumentResponse$.subscribe(value => {
      if (value) {
        this.documentUrl = value.source.url;
      }
    });
  }

  /**
   * Handle step selected changed
   * @param selectedStep the selected step
   */
  stepSelected(selectedStep: ApplicationStep): void {
    this.steps = this.stepperManager.switchStep(selectedStep);
    this.stepIndicator.nativeElement.scrollIntoView();
    this.clearReCaptchaToken();
    const step = this.steps.find(s => s.isCurrent);
    if (step.stepName === 'Finalize') {
      this.submitDocument(false).subscribe(this.createDocumentResponse$);
    }
  }

  /**
   * Next step event handler
   */
  next(): void {
    this.steps = this.stepperManager.next();
    this.stepIndicator.nativeElement.scrollIntoView();
    const step = this.steps.find(s => s.isCurrent);
    if (step.stepName === 'Finalize') {
      this.submitDocument(false).subscribe(this.createDocumentResponse$);
    }
  }

  /**
   * Previous step event handler
   */
  previous(): void {
    this.steps = this.stepperManager.previous();
    this.stepIndicator.nativeElement.scrollIntoView();
    this.clearReCaptchaToken();
  }

  /**
   * Submit form event handler
   */
  submitForms(): void {
    this.validateFinalizeForm();
    if (
      this.subjectForm.valid &&
      this.memberForm.valid &&
      this.personalRepresentativeForm.valid &&
      this.finalizeForm.valid
    ) {
      const {firstName, lastName} = this.finalizeForm.value;
      const submitDocument = this.submitDocument(true, firstName, lastName);
      const sendEmail = this.sendEmail();
      zip(submitDocument, sendEmail)
        .subscribe(([
                      createDocumentResponse,
                      sendEmailResponse
                    ]) => {
          this.submitForm$.next({createDocumentResponse, sendEmailResponse});
        });
    }
  }

  /**
   * Clear ReCaptcha key
   */
  clearReCaptchaToken(): void {
    this.finalizeForm.patchValue({
      reCaptchaKey: ''
    });
  }

  /**
   * Submit a document
   * @param signed is it signed
   * @param firstName the signer first name
   * @param lastName the signer last name
   */
  submitDocument(signed: boolean, firstName?: string, lastName?: string)
    : Observable<CreateDocumentLinkResponse> {
    let singerInformation: SignerInformation;
    if (this.subjectForm.value.hasPersonalRepresentative) {
      if (signed) {
        singerInformation = getSignedSignerInformation(this.subjectForm, firstName, lastName);
      } else {
        singerInformation = getUnsignedSignerInformation(this.subjectForm);
      }
    } else {
      if (signed) {
        singerInformation = getSignedSignerInformation(this.memberForm, firstName, lastName);
      } else {
        singerInformation = getUnsignedSignerInformation(this.memberForm);
      }
    }
    const memberInformation: MemberInformation
      = getMemberInformation(this.memberForm);
    const repInformation: RepInformation
      = getRepInformation(this.personalRepresentativeForm, this.formType);
    const gmcData: GmcData = {
      singerInformation,
      memberInformation,
      repInformation
    };
    const createDocumentRequest: CreateDocumentLinkRequest = {
      project: 'PersonalRepAppointment',
      documentTtl: 720,
      gmcData
    };
    return this.documentService
      .createDocumentLink(createDocumentRequest);
  }

  /**
   * Send email
   */
  sendEmail(): Observable<SendEmailResponse> {
    const singerForm = this.subjectForm.value.hasPersonalRepresentative
      ? this.subjectForm
      : this.memberForm;
    let sendEmailRequest: SendEmailRequest;
    if (this.formType === 'appointment') {
      sendEmailRequest = getSendingEmailRequest(
        singerForm,
        'TRANSACTIONAL',
        'This email is for Personal Rep Privacy Office',
        'This person has requested a personal rep to be added'
      );
    } else {
      sendEmailRequest = getSendingEmailRequest(
        singerForm,
        'TRANSACTIONAL',
        'This email is for Personal Rep Privacy Office',
        'This person has requested a personal rep to be removed'
      );
    }
    return this.emailService
      .createEmail(sendEmailRequest);
  }

  /**
   * Subject form validation event handler
   */
  validateSubjectForm(): void {
    const errors = this.subjectForm.value.signerRelation
      ? SIGNER_FORM_ERRORS
      : SIGNER_FORM_NON_SELECTED_REP_ERRORS;
    this.formService.validate(this.subjectForm, errors);
  }

  /**
   * Member form validation event handler
   */
  validateMemberForm(): void {
    let errors = this.memberForm.value.withWellmarkId
      ? MEMBER_FORM_WITH_WELLMARK_ID_ERRORS
      : MEMBER_FORM_ERRORS;
    errors = typeof this.memberForm.value.withWellmarkId === 'boolean'
      ? errors
      : Object.assign({}, errors, {ssn: {}});
    this.formService.validate(this.memberForm, errors);
  }

  /**
   * Personal representative form validation event handler
   */
  validatePersonalRepForm(): void {
    let errors = this.personalRepresentativeForm.value.identifier === 'ssn'
      ? PERSONAL_PREP_FORM_ERRORS
      : PERSONAL_PREP_FORM_LAST4SSN_ERRORS;
    const isWellmarkMember = this.personalRepresentativeForm.value.isWellmarkMember;
    errors = typeof isWellmarkMember !== 'boolean'
      ? Object.assign({}, errors, {wellmarkId: {}, wellmarkMemberSSN: {}})
      : errors;
    const identifier = this.personalRepresentativeForm.value.identifier;
    errors = identifier
      ? errors
      : Object.assign({}, errors, {ssn: {}});
    this.formService.validate(this.personalRepresentativeForm, errors);
  }

  validateFinalizeForm(): void {
    this.formService.validate(this.finalizeForm, FINALIZE_FORM_ERRORS);
  }

  get isLessThan18(): boolean {
    return moment(this.memberForm.value.dateOfBirth, DATE_FORMAT, true)
      .diff(new Date(), 'years', true) < 18;
  }
}

interface StepperFormSubmitEvent {
  sendEmailResponse: SendEmailResponse;
  createDocumentResponse: CreateDocumentLinkResponse;
}
