import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';
import { DynamicReactiveForm } from '../../../utils/dynamic-reactive-form.util';
import { LAST_FOUR_DIGITS_SSN_PATTERN, SSN_PATTERN, WELLMARK_ID_PATTERN } from '../../../config';

@Component({
  selector: 'app-member-information',
  templateUrl: './member-information.component.html',
  styleUrls: ['./member-information.component.scss']
})
export class MemberInformationComponent implements OnInit {

  @Input() memberForm: FormGroup;

  @Input() subjectForm: FormGroup;

  identifierSelected: boolean;

  selectedIdentifier: 'ssn' | 'wellmarkId+4ssn' | 'not-selected' = 'not-selected';

  dynamicForm: DynamicReactiveForm;

  constructor() { }

  ngOnInit(): void {
    this.dynamicForm = new DynamicReactiveForm(this.memberForm);
    this.memberForm.get('withWellmarkId').valueChanges   // value changes
      .pipe(
        distinctUntilChanged()     // get distinct values
      ).subscribe(withWellmarkId => {
        const identifierSelected = typeof withWellmarkId === 'boolean';

        if (!identifierSelected) {
          this.selectedIdentifier = 'not-selected';
        } else {
          this.selectedIdentifier = withWellmarkId ? 'wellmarkId+4ssn' : 'ssn';
          if (this.selectedIdentifier === 'ssn') {
            this.dynamicForm.removeFromControls(['wellmarkId', 'last4ssn']);
            this.dynamicForm.addFormControls({
              ssn: ['', [Validators.required, Validators.pattern(SSN_PATTERN)]]
            });
          } else {
            this.dynamicForm.removeFromControls(['ssn']);
            this.dynamicForm.addFormControls({
              wellmarkId: ['', [Validators.required, Validators.pattern(WELLMARK_ID_PATTERN)]],
              last4ssn: ['', [Validators.required, Validators.pattern(LAST_FOUR_DIGITS_SSN_PATTERN)]]
            });
          }
        }
    });

    this.memberForm.patchValue(this.memberForm.value);
  }

}
