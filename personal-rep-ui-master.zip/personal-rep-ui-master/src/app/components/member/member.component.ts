import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { DynamicReactiveForm } from '../../utils/dynamic-reactive-form.util';
import { DateValidator } from '../../utils/date-validator.util';
import { DATE_FORMAT, EMAIL_PATTERN, SSN_PATTERN, ZIP_PATTERN } from '../../config';
import { FormService, WellmarkError } from '@wellmark/wm-lib-ux';
import { interval, merge, Observable } from 'rxjs';
import { debounce, distinctUntilChanged, filter, map, switchMap, take } from 'rxjs/operators';
import * as moment from 'moment';
import { FormType } from '../../models/form-type';

@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.scss']
})
export class MemberComponent implements OnInit {

  @Input() memberForm: FormGroup;

  @Input() subjectForm: FormGroup;

  @Input() formType: FormType;

  @Output() previous = new EventEmitter();

  @Output() next = new EventEmitter();

  dynamicForm: DynamicReactiveForm;

  errors$: Observable<WellmarkError[]>;

  showExchangeMembersWarning$: Observable<boolean>;

  showDateOfBirthWarning$: Observable<boolean>;

  ageWarning: WellmarkError = new WellmarkError(
    '',
    'On the member\'s 18th birthday, the personal representative' +
    ' will be effectively removed. A new appointment form will have to be submitted',
    'friendly',
    'original'
  );

  membersWarning: WellmarkError = new WellmarkError(
    '',
    'The ability to appoint a personal representative to share health ' +
    'data is only available to Exchange members who purchased their health insurance ' +
    'through HealthCare.gov. The Wellmark ID provided indicates this is not an Exchange ' +
    'policy so an interoperability personal representative would not be needed.',
    'friendly',
    'original'
  );

  ageWarningMessage: WellmarkError[] = [this.ageWarning];

  membersWarningMessage: WellmarkError[] = [this.membersWarning];

  constructor(private formService: FormService) {
  }

  ngOnInit(): void {
    this.formService.clearErrors();
    this.errors$ = this.formService.errors$;
    this.dynamicForm = new DynamicReactiveForm(this.memberForm);
    this.dynamicForm.addFormControls({
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        dateOfBirth: ['', [Validators.required, DateValidator()]],
        addressLine1: ['', Validators.required],
        addressLine2: [''],
        cityState: ['', Validators.required],
        zipCode: ['',
          [
            Validators.required,
            Validators.pattern(ZIP_PATTERN)
          ]
        ],
        withWellmarkId: ['', Validators.required],
        ssn: ['',
          [
            Validators.required,
            Validators.pattern(SSN_PATTERN)
          ]
        ]
      }
    );

    if (this.subjectForm.value.hasPersonalRepresentative) {
      const {emailAddress} = this.memberForm.value;
      this.dynamicForm.removeFromControls(['emailAddress']);
      this.dynamicForm.addFormControls({
        emailAddress: [emailAddress, Validators.pattern(EMAIL_PATTERN)]
      });
    } else {
      const {emailAddress} = this.memberForm.value;
      this.dynamicForm.removeFromControls(['emailAddress']);
      this.dynamicForm.addFormControls({
        emailAddress: [emailAddress,
          [
            Validators.required,
            Validators.pattern(EMAIL_PATTERN)
          ]
        ],
      });
    }

    this.setIdentifierChangesStream();
    this.setDoBChangesStream();
    this.memberForm.patchValue(this.memberForm.value);
  }

  setIdentifierChangesStream(): void {
    const wellmarkIdChanges = this.memberForm.valueChanges.pipe(  // when value changes
      filter(() => !!this.memberForm.get('wellmarkId')), // allow stream only when wellmarkId available
      switchMap(      // switch to latest stream
        () => this.memberForm.get('wellmarkId').valueChanges   // when wellmark Id changes
          .pipe(
            map(      // map value to ssn, wellmark id changes pair
              (wellmarkId) => ({
                last4ssn: this.memberForm.value.ssn,
                wellmarkId
              })
            )
          )
      )
    );

    const ssnChanges = this.memberForm.valueChanges.pipe(   // when value changes
      filter(() => !!this.memberForm.get('ssn')), // allow stream only when ssn is available
      switchMap(    // switch to latest stream
        () => this.memberForm.get('ssn').valueChanges // when ssn changes
          .pipe(
            map(    // map value to ssn, wellmark id changes pair
              (last4ssn) => ({
                last4ssn,
                wellmarkId: this.memberForm.value.wellmarkId
              })
            )
          )
      )
    );

    this.showExchangeMembersWarning$ = merge(ssnChanges, wellmarkIdChanges) // merge streams
      .pipe(
        debounce(() => interval(300)),
        map(({last4ssn, wellmarkId}) => !!last4ssn || !!wellmarkId),
        filter(show => show),
        take(1)
      );
  }

  /**
   * Set Date of Birth input changes stream
   */
  setDoBChangesStream(): void {
    const dateObBirthChanges = this.memberForm.get('dateOfBirth').valueChanges;
    this.showDateOfBirthWarning$ = dateObBirthChanges.pipe(
      map(date => {
        const parsedDate = moment(date, DATE_FORMAT, true);
        const diff = -parsedDate.diff(new Date(), 'months', true);
        return (17 * 12) + 6 <= diff && diff < (18 * 12);
      }),
      distinctUntilChanged()
    );
  }

  /**
   * Set focus to the element with the given field identifier
   * @param fieldId the field identifier
   */
  setFocus(fieldId: string): void {
    this.formService.focusField(fieldId);
  }

}
