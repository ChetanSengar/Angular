import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MemberComponent } from './member.component';
import { WellmarkAlertModule, WellmarkCardModule, WellmarkFieldModule, WellmarkRadioModule } from '@wellmark/wm-lib-ux';
import { MailingAddressModule } from '../mailing-address/mailing-address.module';
import { MemberInformationComponent } from './member-information/member-information.component';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [MemberComponent, MemberInformationComponent],
  exports: [
    MemberComponent
  ],
  imports: [
    CommonModule,
    WellmarkCardModule,
    MailingAddressModule,
    WellmarkFieldModule,
    WellmarkRadioModule,
    ReactiveFormsModule,
    WellmarkAlertModule,
  ]
})
export class MemberModule { }
