import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./pages/landing/landing.module')
      .then(m => m.LandingModule)
  },
  {
    path: 'appointment',
    loadChildren: () => import('./pages/appointment-form/appointment-form.module')
      .then(m => m.AppointmentFormModule)
  },
  {
    path: 'removal',
    loadChildren: () => import('./pages/removal-form/removal-form.module')
      .then(m => m.RemovalFormModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
