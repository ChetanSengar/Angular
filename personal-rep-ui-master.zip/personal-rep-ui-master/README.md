# Interoperability Personal Rep UI

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.2.1.


## Install dependencies

```bash
npm i
```

## Start local dev server

```bash
# open `http://localhost:4200`
npm run start:open
```

## Configure ReCaptcha keys
###create a reCaptcha keys
Head to reCaptcha dashboard.
```
https://www.google.com/recaptcha/admin
```
* Login with your Gmail account

* Enter a label for your reCaptcha

* For reCaptcha type: select reCAPTCHA v2 then the (I'm not a robot) checkbox option.

* Enter your domain name, the owner email account and accept the term of service.

* After submitting, you will get a SITE, and a SECRET key.

* Head to the following file:`src/reCAPTCHA-key.ts`
* Set your SITE KEY as the value for the parameter `RECAPTCHA_KEY`

## Other commands

```bash
# start local dev server without opening browser
npm start

# lint without fix
npm run lint

# lint with fix
npm run lint:fix

# build in development mode
npm run build

# build in production mode
npm run build:prod

# run a test (watch is active / not using headless chrome mode)
npm run test
```

## Development server

Run `npm run start:open` for a dev server. A new tab will be opened to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `npm run build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `npm run build:prod` command for a production build.

## Running unit tests

Run `npm run test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `npm run e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
