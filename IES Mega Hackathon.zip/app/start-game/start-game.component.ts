import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './start-game.component.html',
  styleUrls: ['./start-game.component.scss']
})
export class StartGameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
