export class ResponseListModel {
  // tslint:disable-next-line:variable-name
  hidden_words_in_gird: Array<{ row: any }>;

}
